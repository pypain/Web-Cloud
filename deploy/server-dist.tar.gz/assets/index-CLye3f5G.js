(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))n(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const s of i.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&n(s)}).observe(document,{childList:!0,subtree:!0});function a(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(o){if(o.ep)return;o.ep=!0;const i=a(o);fetch(o.href,i)}})();const Q=!0,tt="/cloud/api/";let U=0,et=20*1024**3,I=5*1024**3;async function T(t,e={}){const a=await fetch(tt+t,{...e,headers:{"X-Cloud-Request":"1",...e.headers}});if(!a.ok){let n=`Ошибка сервера (${a.status})`;try{n=(await a.json()).error||n}catch{}throw a.status===409&&(n="Хранилище изменилось в другой вкладке. Обновите страницу перед редактированием."),a.status===413&&(n="Превышен лимит файла или объём хранилища."),a.status===507&&(n="Недостаточно свободного места на сервере."),new Error(n)}return a}async function gt(){const t=await(await T("state")).json();return U=t.version,et=t.quota,I=t.maxFile,t}async function yt(t){for(const n of t)if(n.kind==="file"&&n.blob&&!n._stored){if(n.blob.size>I)throw new Error(`Файл «${n.name}» превышает лимит ${Math.round(I/1024**3)} ГБ.`);await T(`files/${n.id}`,{method:"PUT",body:n.blob}),n._stored=!0}const e=t.map(({blob:n,...o})=>o);U=(await(await T("state",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({version:U,entries:e})})).json()).version}function at(t,e=!1){return tt+`files/${t.id}`+(e?"?download=1":"")}async function $t(t){return(await T(`files/${t.id}`,{headers:t.size?{Range:"bytes=0-199999"}:{}})).text()}/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nt=(t,e,a=[])=>{const n=document.createElementNS("http://www.w3.org/2000/svg",t);return Object.keys(e).forEach(o=>{n.setAttribute(o,String(e[o]))}),a.length&&a.forEach(o=>{const i=nt(...o);n.appendChild(i)}),n};var wt=([t,e,a])=>nt(t,e,a);/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xt=t=>Array.from(t.attributes).reduce((e,a)=>(e[a.name]=a.value,e),{}),kt=t=>typeof t=="string"?t:!t||!t.class?"":t.class&&typeof t.class=="string"?t.class.split(" "):t.class&&Array.isArray(t.class)?t.class:"",Mt=t=>t.flatMap(kt).map(a=>a.trim()).filter(Boolean).filter((a,n,o)=>o.indexOf(a)===n).join(" "),Et=t=>t.replace(/(\w)(\w*)(_|-|\s*)/g,(e,a,n)=>a.toUpperCase()+n.toLowerCase()),K=(t,{nameAttr:e,icons:a,attrs:n})=>{var Z;const o=t.getAttribute(e);if(o==null)return;const i=Et(o),s=a[i];if(!s)return console.warn(`${t.outerHTML} icon name was not found in the provided icons object.`);const u=xt(t),[f,b,O]=s,A={...b,"data-lucide":o,...n,...u},B=Mt(["lucide",`lucide-${o}`,u,n]);B&&Object.assign(A,{class:B});const bt=wt([f,A,O]);return(Z=t.parentNode)==null?void 0:Z.replaceChild(bt,t)};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const At=["svg",c,[["path",{d:"M3.5 13h6"}],["path",{d:"m2 16 4.5-9 4.5 9"}],["path",{d:"M18 7v9"}],["path",{d:"m14 12 4 4 4-4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Lt=["svg",c,[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"}],["path",{d:"M10 12h4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const St=["svg",c,[["path",{d:"m3 16 4 4 4-4"}],["path",{d:"M7 20V4"}],["path",{d:"m21 8-4-4-4 4"}],["path",{d:"M17 4v16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ct=["svg",c,[["path",{d:"M12 5v14"}],["path",{d:"m19 12-7 7-7-7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dt=["svg",c,[["path",{d:"M7 7h10v10"}],["path",{d:"M7 17 17 7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ht=["svg",c,[["path",{d:"m5 12 7-7 7 7"}],["path",{d:"M12 19V5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tt=["svg",c,[["path",{d:"M8 2v4"}],["path",{d:"M16 2v4"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2"}],["path",{d:"M3 10h18"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qt=["svg",c,[["path",{d:"M20 6 9 17l-5-5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zt=["svg",c,[["path",{d:"m6 9 6 6 6-6"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jt=["svg",c,[["path",{d:"m9 18 6-6-6-6"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nt=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ft=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"}],["path",{d:"M12 17h.01"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=["svg",c,[["path",{d:"M12 13v8"}],["path",{d:"M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"}],["path",{d:"m8 17 4-4 4 4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ut=["svg",c,[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const It=["svg",c,[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["polyline",{points:"7 10 12 15 17 10"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pt=["svg",c,[["circle",{cx:"12",cy:"12",r:"1"}],["circle",{cx:"19",cy:"12",r:"1"}],["circle",{cx:"5",cy:"12",r:"1"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rt=["svg",c,[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"}],["circle",{cx:"12",cy:"12",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vt=["svg",c,[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"M10 9H8"}],["path",{d:"M16 13H8"}],["path",{d:"M16 17H8"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wt=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M7 3v18"}],["path",{d:"M3 7.5h4"}],["path",{d:"M3 12h18"}],["path",{d:"M3 16.5h4"}],["path",{d:"M17 3v18"}],["path",{d:"M17 7.5h4"}],["path",{d:"M17 16.5h4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xt=["svg",c,[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}],["path",{d:"M2 10h20"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bt=["svg",c,[["path",{d:"M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1"}],["path",{d:"M2 13h10"}],["path",{d:"m9 16 3-3-3-3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zt=["svg",c,[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=["svg",c,[["path",{d:"M12 10v6"}],["path",{d:"M9 13h6"}],["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _t=["svg",c,[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yt=["svg",c,[["line",{x1:"22",x2:"2",y1:"12",y2:"12"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=["svg",c,[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}],["circle",{cx:"9",cy:"9",r:"2"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qt=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=["svg",c,[["rect",{width:"7",height:"7",x:"3",y:"3",rx:"1"}],["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1"}],["rect",{width:"7",height:"7",x:"14",y:"14",rx:"1"}],["rect",{width:"7",height:"7",x:"3",y:"14",rx:"1"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=["svg",c,[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=["svg",c,[["path",{d:"M3 12h.01"}],["path",{d:"M3 18h.01"}],["path",{d:"M3 6h.01"}],["path",{d:"M8 12h13"}],["path",{d:"M8 18h13"}],["path",{d:"M8 6h13"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=["svg",c,[["line",{x1:"4",x2:"20",y1:"12",y2:"12"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=["svg",c,[["path",{d:"M9 18V5l12-2v13"}],["circle",{cx:"6",cy:"18",r:"3"}],["circle",{cx:"18",cy:"16",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=["svg",c,[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"}],["path",{d:"m15 5 4 4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=["svg",c,[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=["svg",c,[["path",{d:"m13.5 8.5-5 5"}],["path",{d:"m8.5 8.5 5 5"}],["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=["svg",c,[["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=["svg",c,[["path",{d:"M20 7h-9"}],["path",{d:"M14 17H5"}],["circle",{cx:"17",cy:"17",r:"3"}],["circle",{cx:"7",cy:"7",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}],["line",{x1:"3",x2:"21",y1:"9",y2:"9"}],["line",{x1:"3",x2:"21",y1:"15",y2:"15"}],["line",{x1:"9",x2:"9",y1:"9",y2:"21"}],["line",{x1:"15",x2:"15",y1:"9",y2:"21"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=["svg",c,[["path",{d:"M3 6h18"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=["svg",c,[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["polyline",{points:"17 8 12 3 7 8"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=["svg",c,[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=({icons:t={},nameAttr:e="data-lucide",attrs:a={}}={})=>{if(!Object.values(t).length)throw new Error(`Please provide an icons object.
If you want to use all the icons you can import it like:
 \`import { createIcons, icons } from 'lucide';
lucide.createIcons({icons});\``);if(typeof document>"u")throw new Error("`createIcons()` only works in a browser environment.");const n=document.querySelectorAll(`[${e}]`);if(Array.from(n).forEach(o=>K(o,{nameAttr:e,icons:t,attrs:a})),e==="data-lucide"){const o=document.querySelectorAll("[icon-name]");o.length>0&&(console.warn("[Lucide] Some icons were found with the now deprecated icon-name attribute. These will still be replaced for backwards compatibility, but will no longer be supported in v1.0 and you should switch to data-lucide"),Array.from(o).forEach(i=>K(i,{nameAttr:"icon-name",icons:t,attrs:a})))}},F={Cloud:Ut,FolderClosed:Xt,Link:ee,Trash2:ue,HardDrive:Yt,ArrowUpRight:Dt,Settings2:ce,Menu:ne,CircleHelp:Ft,FolderPlus:Kt,Upload:pe,Search:re,X:he,ArrowDownUp:St,ChevronDown:zt,List:ae,LayoutGrid:te,House:Gt,ChevronRight:jt,ArrowDown:Ct,ArrowUp:Ht,Ellipsis:Pt,UploadCloud:Ot,RotateCcw:ie,Download:It,FolderInput:Bt,Info:Qt,Check:qt,CircleAlert:Nt,Eye:Rt,Pencil:se,Calendar:Tt,AArrowDown:At,Folder:_t,Image:Jt,FileText:Vt,Sheet:de,Archive:Lt,Film:Wt,Music:oe,FolderOpen:Zt,SearchX:le},l=(t,e=document)=>e.querySelector(t),m=t=>String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),r=(t,e="")=>`<i data-lucide="${t}" class="${e}" aria-hidden="true"></i>`,L=t=>t>=1073741824?`${(t/1073741824).toLocaleString("ru",{maximumFractionDigits:1})} ГБ`:t<1024?`${t} Б`:t<1048576?`${(t/1024).toLocaleString("ru",{maximumFractionDigits:1})} КБ`:`${(t/1048576).toLocaleString("ru",{maximumFractionDigits:1})} МБ`,ot=t=>new Date(t).toLocaleDateString("ru",{day:"numeric",month:"short",year:"numeric"});let S=!1,h=[],d="files",w=null,p=new Set,$=null,y="",k="name",q=!0,E="list",_=[];const z=()=>crypto.randomUUID(),C=()=>h.filter(t=>!t.deleted),v=t=>h.find(e=>e.id===t),Y=t=>{var e,a,n;return t.kind==="folder"?"folder":(e=t.mime)!=null&&e.startsWith("image/")?"image":t.mime==="application/pdf"?"file-text":/\.(xlsx|csv)$/i.test(t.name)?"sheet":/\.(zip|rar)$/i.test(t.name)?"archive":(a=t.mime)!=null&&a.startsWith("video/")?"film":(n=t.mime)!=null&&n.startsWith("audio/")?"music":"file-text"};function st(t){return`<span class="file-icon ${Y(t)}">${r(Y(t))}</span>`}async function fe(){let t;{const e=await gt();h=e.entries,t=e.version>0}if(!t&&!h.length){const e=Date.now();h=["Документы","Фотографии","Проекты"].map(n=>({id:z(),name:n,kind:"folder",parent:null,modified:e,size:0}));const a=new Blob([`Добро пожаловать в Личное облако!

Файлы сохраняются на сервере и доступны с других устройств после входа. Публичные ссылки пока отключены.
`],{type:"text/plain"});h.push({id:z(),name:"Начните здесь.txt",kind:"file",parent:null,modified:e,size:a.size,mime:a.type,blob:a}),await it()}g()}async function it(){return yt(h)}async function M(t,e){if(S)return x("Дождитесь завершения сохранения или загрузки.");const a=structuredClone(h);S=!0;try{t(),g(),Q&&x("Сохранение на сервере…"),await it(),e&&x(e)}catch(n){h=a,g(),x(n.message,!0)}finally{S=!1}}function lt(){let t=h.filter(e=>{var a;return d==="trash"?e.deleted&&!((a=v(e.parent))!=null&&a.deleted):d==="links"?!e.deleted&&e.shared:!e.deleted&&(y?!0:e.parent===w)});return y&&(t=t.filter(e=>e.name.toLocaleLowerCase().includes(y.toLocaleLowerCase()))),t.sort((e,a)=>(e.kind===a.kind?0:e.kind==="folder"?-1:1)||(k==="name"?e.name.localeCompare(a.name,"ru"):(e[k]||0)-(a[k]||0))*(q?1:-1))}function V(t){const e=[];let a=v(t);const n=new Set;for(;a&&!n.has(a.id);)e.unshift(a),n.add(a.id),a=v(a.parent);return e}function D(t,e){return V(t).some(a=>a.id===e)}function G(t){d=t,w=null,p.clear(),$=null,y="",g()}function rt(t){w=t,d="files",y="",p.clear(),$=null,g()}function g(){var i;_.forEach(URL.revokeObjectURL),_=[];const t=lt(),e=v($),a=h.reduce((s,u)=>s+(u.size||0),0),n=C().filter(s=>s.kind==="file").length,o={files:"Мои файлы",links:"Общие ссылки",trash:"Корзина"};l("#app").innerHTML=`<div class="layout">
    <aside class="sidebar" id="sidebar"><a class="brand" href="#" aria-label="Личное облако, главная">${r("cloud")}<span>Личное<span class="brand-sub">облако</span></span><span class="brand-dot"></span></a>
    <div class="workspace-label">ЛИЧНОЕ ПРОСТРАНСТВО</div><nav aria-label="Основная навигация">${[["files","folder-closed","Мои файлы"],["links","link","Общие ссылки"],["trash","trash-2","Корзина"]].map(([s,u,f])=>`<button class="nav-item ${d===s?"active":""}" data-nav="${s}">${r(u)}<span>${f}</span>${s==="files"?`<span class="nav-count">${n}</span>`:""}</button>`).join("")}</nav>
    <div class="sidebar-bottom"><div class="storage-heading">${r("hard-drive")}<span>Хранилище сервера</span></div><div class="storage-value">${L(a)} <span>занято файлами</span></div><div class="storage-track"><span id="storage-fill"></span></div><p>Доступно с ваших устройств</p><button class="storage-details" data-action="storage">Подробнее ${r("arrow-up-right")}</button></div>
    <button class="profile" data-action="settings"><span class="avatar">Л</span><span>Личное пространство<small>Личное хранилище</small></span>${r("settings-2")}</button></aside>
    <div class="sidebar-shade" data-action="close-nav"></div>
    <main><header class="topbar"><button class="icon-button mobile-menu" data-action="menu" aria-label="Открыть навигацию">${r("menu")}</button><div class="top-location">Пространство <span>/</span> <strong>${o[d]}</strong></div><div class="top-right"><span class="local-tag"><span></span>На сервере</span><button class="icon-button" data-action="help" aria-label="Помощь">${r("circle-help")}</button><span class="avatar small">Л</span></div></header>
    <div class="content"><div class="page-heading"><div><div class="eyebrow">ВАШЕ ЛИЧНОЕ ОБЛАКО</div><h1>${m(d==="files"&&w?(i=v(w))==null?void 0:i.name:o[d])}</h1><p>${d==="files"?"Всё нужное — на своём месте.":d==="links"?"Файлы, которые вы подготовили для обмена.":"Удалённые файлы можно восстановить."}</p></div><div class="heading-actions">${d==="files"?`<button class="button secondary" data-action="new-folder">${r("folder-plus")}<span>Новая папка</span></button><button class="button primary" data-action="upload">${r("upload")}<span>Загрузить файлы</span></button>`:d==="trash"?`<button class="button secondary danger" data-action="empty-trash" ${t.length?"":"disabled"}>${r("trash-2")}Очистить корзину</button>`:""}</div></div>
    ${d==="links"?`<div class="notice">${r("info")}<span>Публичные ссылки отключены. Этот список виден только после входа.</span></div>`:""}
    <div class="file-toolbar"><label class="search">${r("search")}<input id="search" placeholder="Поиск файлов и папок" aria-label="Поиск файлов и папок" value="${m(y)}" autocomplete="off">${y?`<button class="icon-button" data-action="clear-search" aria-label="Очистить поиск">${r("x")}</button>`:"<kbd>/</kbd>"}</label><div class="toolbar-right"><button class="sort-button" data-action="sort">${r("arrow-down-up")}<span>${k==="name"?"По названию":k==="size"?"По размеру":"По дате"}</span>${r("chevron-down")}</button><div class="view-toggle"><button class="icon-button ${E==="list"?"on":""}" data-view="list" aria-label="Список" aria-pressed="${E==="list"}">${r("list")}</button><button class="icon-button ${E==="grid"?"on":""}" data-view="grid" aria-label="Плитки" aria-pressed="${E==="grid"}">${r("layout-grid")}</button></div></div></div>
    <div class="breadcrumb"><button data-folder="">${r("house")}<span>${d==="files"?"Все файлы":o[d]}</span></button>${d==="files"?V(w).map(s=>`${r("chevron-right")}<button data-folder="${s.id}">${m(s.name)}</button>`).join(""):""}<span class="item-count">${t.length} ${me(t.length,"элемент","элемента","элементов")}${y?" найдено":""}</span></div>
    <div class="files-area ${e?"with-preview":""}"><section class="file-panel" aria-label="Файлы"><div class="table-head"><label class="check"><input type="checkbox" id="select-all" aria-label="Выбрать все файлы" ${t.length&&t.every(s=>p.has(s.id))?"checked":""}></label><button data-sort="name">Название ${r(k==="name"&&!q?"arrow-down":"arrow-up")}</button><button class="size-col" data-sort="size">Размер</button><button class="date-col" data-sort="modified">Изменено</button><span></span></div><div class="file-items ${E}">${t.map(s=>`<div class="file-row ${p.has(s.id)?"selected":""} ${$===s.id?"previewed":""}" data-id="${s.id}" tabindex="0" role="group" aria-label="${m(s.name)}"><label class="check"><input type="checkbox" data-select="${s.id}" aria-label="Выбрать ${m(s.name)}" ${p.has(s.id)?"checked":""}></label><button class="file-name" data-open="${s.id}">${st(s)}<span class="file-label">${m(s.name)}<small>${s.kind==="folder"?"Папка":L(s.size)}</small></span>${s.shared?r("link","shared-mark"):""}</button><span class="size-col">${s.kind==="folder"?"—":L(s.size)}</span><span class="date-col">${ot(s.modified)}</span><button class="icon-button row-more" data-more="${s.id}" aria-label="Действия: ${m(s.name)}">${r("ellipsis")}</button></div>`).join("")||`<div class="empty">${r(y?"search-x":d==="trash"?"trash-2":d==="links"?"link":"folder-open")}<h2>${y?"Ничего не найдено":d==="trash"?"Корзина пуста":d==="links"?"Пока нет файлов для обмена":"Здесь пока пусто"}</h2><p>${y?"Попробуйте другое название.":d==="trash"?"Удалённые файлы появятся здесь.":d==="links"?"Выберите файл и нажмите «Поделиться».":"Загрузите файлы или создайте первую папку."}</p>${d==="files"&&!y?'<button class="button secondary" data-action="upload">Загрузить файлы</button>':""}</div>`}</div><div class="drop-hint">${r("upload-cloud")}<span>Перетащите файлы сюда для загрузки</span></div></section>${e?ve(e):""}</div>
    <footer class="content-footer"><span>${r("hard-drive")} Файлы хранятся на сервере</span><button data-action="help">Как это работает ${r("arrow-up-right")}</button></footer></div>
    ${p.size?`<div class="selection-bar"><button class="icon-button" data-action="deselect" aria-label="Снять выделение">${r("x")}</button><span class="selection-count">Выбрано: <strong>${p.size}</strong></span><div class="selection-actions">${d==="trash"?`<button data-action="restore">${r("rotate-ccw")}<span>Восстановить</span></button><button class="danger" data-action="delete">${r("trash-2")}<span>Удалить навсегда</span></button>`:`<button data-action="download">${r("download")}<span>Скачать</span></button><button data-action="share">${r("link")}<span>Поделиться</span></button><button data-action="move">${r("folder-input")}<span>Переместить</span></button><button data-action="trash">${r("trash-2")}<span>В корзину</span></button>`}</div></div>`:""}
    </main></div><input id="file-input" type="file" multiple hidden><div id="overlay-root"></div><div id="toast-root" role="status" aria-live="polite"></div><div id="drop-overlay">${r("upload-cloud")}<h2>Отпустите файлы для загрузки</h2><p>В текущую папку</p></div>`,be(),N({icons:F}),Promise.resolve({quota:et}).then(({quota:s})=>{const u=l("#storage-fill");u&&(u.style.width=`${s?Math.min(100,a/s*100):0}%`)}).catch(()=>{})}function me(t,e,a,n){return t%10===1&&t%100!==11?e:t%10>=2&&t%10<=4&&(t%100<12||t%100>14)?a:n}function ve(t){var a,n,o,i,s;let e="";if(t.blob||t.kind==="file"){const u=at(t);e=(a=t.mime)!=null&&a.startsWith("image/")?`<img src="${u}" alt="${m(t.name)}">`:(n=t.mime)!=null&&n.startsWith("video/")?`<video controls src="${u}"></video>`:(o=t.mime)!=null&&o.startsWith("audio/")?`<audio controls src="${u}"></audio>`:t.mime==="application/pdf"?`<iframe src="${u}" title="${m(t.name)}"></iframe>`:(i=t.mime)!=null&&i.startsWith("text/")||/\.(md|json|csv|log)$/i.test(t.name)?'<pre id="text-preview">Загрузка…</pre>':`<div class="unsupported">${st(t)}<p>Предпросмотр недоступен.<br>Скачайте файл, чтобы открыть его.</p></div>`}return`<aside class="preview-panel" aria-label="Предпросмотр"><div class="preview-heading"><span>ПРЕДПРОСМОТР</span><button class="icon-button" data-action="close-preview" aria-label="Закрыть предпросмотр">${r("x")}</button></div><div class="preview-media">${e}</div><h2>${m(t.name)}</h2><span class="file-type">${m(t.mime||"Файл")}</span><dl><div><dt>Размер</dt><dd>${L(t.size)}</dd></div><div><dt>Изменено</dt><dd>${ot(t.modified)}</dd></div><div><dt>Расположение</dt><dd>${m(((s=v(t.parent))==null?void 0:s.name)||"Все файлы")}</dd></div></dl><button class="button primary full" data-download="${t.id}">${r("download")}Скачать файл</button>${t.deleted?"":`<button class="button secondary full" data-share="${t.id}">${r("link")}Поделиться</button>`}</aside>`}function be(){document.querySelectorAll("[data-nav]").forEach(e=>e.onclick=()=>G(e.dataset.nav)),l(".brand").onclick=e=>{e.preventDefault(),G("files")},document.querySelectorAll("[data-action]").forEach(e=>e.onclick=a=>ge(e.dataset.action,a)),document.querySelectorAll("[data-folder]").forEach(e=>e.onclick=()=>rt(e.dataset.folder||null)),document.querySelectorAll("[data-view]").forEach(e=>e.onclick=()=>{E=e.dataset.view,g()}),document.querySelectorAll("[data-sort]").forEach(e=>e.onclick=()=>ct(e.dataset.sort)),document.querySelectorAll("[data-open]").forEach(e=>e.onclick=()=>P(e.dataset.open)),document.querySelectorAll("[data-select]").forEach(e=>e.onchange=()=>{e.checked?p.add(e.dataset.select):p.delete(e.dataset.select),g()}),document.querySelectorAll("[data-more]").forEach(e=>e.onclick=a=>J(a,e.dataset.more)),document.querySelectorAll("[data-download]").forEach(e=>e.onclick=()=>W([e.dataset.download])),document.querySelectorAll("[data-share]").forEach(e=>e.onclick=()=>X([e.dataset.share])),document.querySelectorAll(".file-row").forEach(e=>{e.oncontextmenu=a=>{a.preventDefault(),J(a,e.dataset.id)},e.onkeydown=a=>{a.target===e&&a.key==="Enter"&&P(e.dataset.id)}}),l("#select-all").onchange=e=>{lt().forEach(a=>e.target.checked?p.add(a.id):p.delete(a.id)),g()},l("#search").oninput=e=>{const a=e.target.selectionStart;y=e.target.value,p.clear(),g(),l("#search").focus(),l("#search").setSelectionRange(a,a)},l("#file-input").onchange=e=>pt([...e.target.files]);const t=v($);l("#text-preview")&&t&&(t.blob||Q)&&$t(t).then(e=>{$===t.id&&l("#text-preview")&&(l("#text-preview").textContent=e+(t.size>2e5?`
… Показаны первые 200 КБ`:""))}).catch(()=>{l("#text-preview")&&(l("#text-preview").textContent="Не удалось загрузить предпросмотр")})}function P(t){if(S)return x("Дождитесь завершения загрузки.");const e=v(t);if(e.kind==="folder"){if(e.deleted)return x("Сначала восстановите папку");rt(t)}else $=t,g()}function ct(t){q=k===t?!q:!0,k=t,g()}function ge(t,e){const a=[...p];t==="upload"&&l("#file-input").click(),t==="new-folder"&&dt(),t==="deselect"&&(p.clear(),g()),t==="close-preview"&&($=null,g()),t==="download"&&W(a),t==="share"&&X(a),t==="move"&&mt(a),t==="trash"&&ht(a),t==="restore"&&ft(a),t==="delete"&&R(a),t==="empty-trash"&&R(h.filter(n=>n.deleted).map(n=>n.id)),t==="clear-search"&&(y="",g(),l("#search").focus()),t==="menu"&&l(".layout").classList.add("nav-open"),t==="close-nav"&&l(".layout").classList.remove("nav-open"),t==="sort"&&vt(e,[["name","По названию","a-arrow-down"],["modified","По дате изменения","calendar"],["size","По размеру","hard-drive"]].map(([n,o,i])=>({label:o,icon:i,run:()=>ct(n)}))),["help","settings","storage"].includes(t)&&$e(t)}function x(t,e=!1){const a=l("#toast-root");a.innerHTML=`<div class="toast ${e?"error":""}">${r(e?"circle-alert":"check")}${m(t)}</div>`,N({icons:F}),setTimeout(()=>{S||a.replaceChildren()},4500)}function H(t,e,a,n){const o=document.activeElement;l("#overlay-root").innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-heading"><h2 id="modal-title">${t}</h2><button class="icon-button" data-close aria-label="Закрыть">${r("x")}</button></div><div class="modal-body">${e}</div><div class="modal-actions">${a}</div></section></div>`;const i=()=>{l("#overlay-root").replaceChildren(),o==null||o.focus()};document.querySelectorAll("[data-close]").forEach(s=>s.onclick=i),l(".modal-backdrop").onclick=s=>{s.target===s.currentTarget&&i()},l(".modal").onkeydown=s=>{if(s.key==="Escape"&&i(),s.key==="Tab"){const u=[...l(".modal").querySelectorAll("button:not(:disabled),input,select,a[href]")],f=u[0],b=u.at(-1);s.shiftKey&&document.activeElement===f?(s.preventDefault(),b.focus()):!s.shiftKey&&document.activeElement===b&&(s.preventDefault(),f.focus())}},n==null||n(i),N({icons:F}),setTimeout(()=>{var s;return(s=l(".modal input")||l(".modal button"))==null?void 0:s.focus()},0)}function dt(t){const e=v(t);H(e?"Переименовать":"Новая папка",`<label class="field-label" for="entry-name">Название</label><input class="text-input" id="entry-name" maxlength="200" value="${m((e==null?void 0:e.name)||"")}" placeholder="Например, Документы"><p class="form-error" id="name-error"></p>`,`<button class="button secondary" data-close>Отмена</button><button class="button primary" id="save-name">${e?"Сохранить":"Создать папку"}</button>`,a=>{const n=async()=>{const o=l("#entry-name").value.trim();if(!o||/[\/\\\x00-\x1f]/.test(o)||o==="."||o==="..")return l("#name-error").textContent="Введите название без слешей и служебных символов.";if(C().some(i=>i.id!==t&&i.parent===(e?e.parent:w)&&i.name===o))return l("#name-error").textContent="Такое название уже есть в этой папке.";a(),await M(()=>{e?(e.name=o,e.modified=Date.now()):h.push({id:z(),name:o,kind:"folder",parent:w,modified:Date.now(),size:0})},e?"Название изменено":"Папка создана")};l("#save-name").onclick=n,l("#entry-name").onkeydown=o=>{o.key==="Enter"&&n()},l("#entry-name").select()})}function ut(t,e){let a=t,n=1;const o=t.lastIndexOf("."),i=o>0?t.slice(0,o):t,s=o>0?t.slice(o):"";for(;C().some(u=>u.parent===e&&u.name===a);)a=`${i} (${n++})${s}`;return a}async function pt(t){if(d!=="files")return x("Откройте «Мои файлы» для загрузки");t.length&&await M(()=>t.forEach(e=>h.push({id:z(),name:ut(e.name,w),kind:"file",parent:w,modified:Date.now(),size:e.size,mime:e.type,blob:e})),`Загружено файлов: ${t.length}`)}function W(t){const e=t.map(v).filter(a=>(a==null?void 0:a.blob)||(a==null?void 0:a.kind)==="file");if(!e.length)return x("Откройте папку и выберите файлы для скачивания");for(const a of e){const n=at(a,!0),o=document.createElement("a");o.href=n,o.download=a.name,o.click()}e.length<t.length&&x("Скачаны файлы. Папки нужно открыть отдельно.")}function ht(t){M(()=>{h.forEach(e=>{t.some(a=>D(e.id,a))&&(e.deleted=Date.now())}),p.clear(),$=null},"Перемещено в корзину")}function ft(t){M(()=>{h.filter(a=>t.some(n=>D(a.id,n))).forEach(a=>delete a.deleted),t.forEach(a=>{var o;const n=v(a);n&&(!v(n.parent)||(o=v(n.parent))!=null&&o.deleted)&&(n.parent=null),n&&(n.name=ye(n))}),p.clear()},"Восстановлено")}function ye(t){const e=t.name;t.name="";const a=ut(e,t.parent);return t.name=e,a}function R(t){H("Удалить навсегда?",`<p>Будет удалено элементов: <strong>${t.length}</strong>. Содержимое выбранных папок тоже будет удалено. Восстановить их не получится.</p>`,'<button class="button secondary" data-close>Отмена</button><button class="button destructive" id="confirm-delete">Удалить навсегда</button>',e=>{l("#confirm-delete").onclick=()=>{e(),M(()=>{const a=h.filter(n=>t.some(o=>D(n.id,o))).map(n=>n.id);h=h.filter(n=>!a.includes(n.id)),p.clear(),$=null},"Удалено навсегда")}})}function mt(t){const e=C().filter(a=>a.kind==="folder"&&!t.some(n=>D(a.id,n)));H("Переместить",`<p>Выберите папку назначения.</p><label class="field-label" for="destination">Папка</label><select class="text-input" id="destination"><option value="">Все файлы</option>${e.map(a=>`<option value="${a.id}">${m(V(a.id).map(n=>n.name).join(" / "))}</option>`).join("")}</select><p class="form-error" id="move-error"></p>`,'<button class="button secondary" data-close>Отмена</button><button class="button primary" id="confirm-move">Переместить</button>',a=>{l("#confirm-move").onclick=()=>{const n=l("#destination").value||null,o=t.map(v).filter(i=>i&&!t.some(s=>s!==i.id&&D(i.id,s)));if(o.some(i=>C().some(s=>s.parent===n&&s.name===i.name&&s.id!==i.id)))return l("#move-error").textContent="В папке назначения уже есть элемент с таким названием.";a(),M(()=>{o.forEach(i=>{i.parent=n,i.modified=Date.now()}),p.clear()},"Перемещено")}})}function X(t){const e=t.map(v).filter(Boolean),a=e.every(n=>n.shared);H("Поделиться",`<div class="dialog-symbol">${r("link")}</div><p><strong>${e.length===1?m(e[0].name):`Выбрано элементов: ${e.length}`}</strong></p><p>Файлы хранятся на сервере за вашим паролем. Публичные ссылки в этой версии отключены.</p><p>Пока можно ${a?"убрать их из":"добавить их в"} раздел «Общие ссылки» или скачать файл и отправить его самостоятельно.</p>`,`<button class="button secondary" data-close>Закрыть</button><button class="button primary" id="prepare-share">${a?"Убрать из списка":"Подготовить к обмену"}</button>`,n=>{l("#prepare-share").onclick=()=>{n(),M(()=>e.forEach(o=>o.shared=!a),a?"Убрано из общих ссылок":"Добавлено в общие ссылки")}})}function $e(t){const e=h.reduce((a,n)=>a+(n.size||0),0);H(t==="storage"?"Хранилище":t==="settings"?"Личное пространство":"Как это работает",`<div class="dialog-symbol">${r(t==="storage"?"hard-drive":"cloud")}</div><p>Файлы сохраняются на сервере и доступны с других устройств после входа.</p><dl class="info-list"><div><dt>Занято файлами</dt><dd>${L(e)}</dd></div><div><dt>Файлов</dt><dd>${h.filter(a=>a.kind==="file").length}</dd></div><div><dt>Хранение</dt><dd>На сервере</dd></div></dl><p>Корзина тоже занимает место. Данные в браузере из прежней версии автоматически не перенесены: скачайте их в старой версии и загрузите сюда. Резервное копирование сервера на отдельное устройство ещё нужно настроить.</p>${t==="help"?"<p><kbd>/</kbd> — поиск · <kbd>Esc</kbd> — закрыть окно или снять выделение. Файлы можно загружать перетаскиванием.</p>":""}`,'<button class="button primary" data-close>Понятно</button>')}function J(t,e){const a=v(e),n=p.has(e)?[...p]:[e];vt(t,a.deleted?[{label:"Восстановить",icon:"rotate-ccw",run:()=>ft(n)},{label:"Удалить навсегда",icon:"trash-2",danger:!0,run:()=>R(n)}]:[{label:a.kind==="folder"?"Открыть папку":"Предпросмотр",icon:a.kind==="folder"?"folder-open":"eye",run:()=>P(e)},...a.kind==="file"?[{label:"Скачать",icon:"download",run:()=>W(n)}]:[],{label:"Поделиться",icon:"link",run:()=>X(n)},{label:"Переименовать",icon:"pencil",run:()=>dt(e)},{label:"Переместить",icon:"folder-input",run:()=>mt(n)},{label:"В корзину",icon:"trash-2",danger:!0,run:()=>ht(n)}])}function vt(t,e){var s,u;(s=l(".context-menu"))==null||s.remove();const a=document.createElement("div");a.className="context-menu",a.setAttribute("role","menu"),a.innerHTML=e.map((f,b)=>`<button role="menuitem" class="${f.danger?"danger":""}" data-menu-index="${b}">${r(f.icon)}${f.label}</button>`).join(""),document.body.append(a);const n=(u=t.currentTarget)==null?void 0:u.getBoundingClientRect(),o=t.type==="contextmenu"?t.clientX:(n==null?void 0:n.right)||t.clientX,i=t.type==="contextmenu"?t.clientY:(n==null?void 0:n.bottom)||t.clientY;a.style.left=`${Math.max(8,Math.min(o-200,innerWidth-220))}px`,a.style.top=`${Math.max(8,Math.min(i+5,innerHeight-a.offsetHeight-10))}px`,a.querySelectorAll("button").forEach((f,b)=>f.onclick=()=>{a.remove(),e[b].run()}),a.onkeydown=f=>{var A;const b=[...a.querySelectorAll("button")];let O=b.indexOf(document.activeElement);(f.key==="ArrowDown"||f.key==="ArrowUp")&&(f.preventDefault(),b[(O+(f.key==="ArrowDown"?1:b.length-1))%b.length].focus()),f.key==="Escape"&&(a.remove(),(A=t.currentTarget)==null||A.focus())},N({icons:F}),a.querySelector("button").focus(),setTimeout(()=>document.addEventListener("click",function f(b){a.contains(b.target)||(a.remove(),document.removeEventListener("click",f))},{capture:!0}),0)}let j=0;document.addEventListener("dragenter",t=>{var e,a;(e=t.dataTransfer)!=null&&e.types.includes("Files")&&(t.preventDefault(),j++,d==="files"&&((a=l("#drop-overlay"))==null||a.classList.add("show")))});document.addEventListener("dragover",t=>{var e;(e=t.dataTransfer)!=null&&e.types.includes("Files")&&t.preventDefault()});document.addEventListener("dragleave",()=>{var t;--j<=0&&(j=0,(t=l("#drop-overlay"))==null||t.classList.remove("show"))});document.addEventListener("drop",t=>{var e;t.preventDefault(),j=0,(e=l("#drop-overlay"))==null||e.classList.remove("show"),pt([...t.dataTransfer.files])});document.addEventListener("keydown",t=>{var e,a,n;if(t.key==="Escape"){if(l(".modal"))return;(e=l(".context-menu"))==null||e.remove(),(a=l(".layout"))==null||a.classList.remove("nav-open"),p.clear(),$=null,g()}t.key==="/"&&!["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName)&&!l(".modal")&&(t.preventDefault(),(n=l("#search"))==null||n.focus())});fe().catch(()=>{l("#app").innerHTML='<div class="fatal"><h1>Серверное хранилище недоступно</h1><p>Проверьте подключение и обновите страницу.</p><button onclick="location.reload()">Попробовать снова</button></div>'});
