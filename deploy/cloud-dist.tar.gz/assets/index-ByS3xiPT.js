(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))n(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const d of i.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&n(d)}).observe(document,{childList:!0,subtree:!0});function a(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(o){if(o.ep)return;o.ep=!0;const i=a(o);fetch(o.href,i)}})();/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=(t,e,a=[])=>{const n=document.createElementNS("http://www.w3.org/2000/svg",t);return Object.keys(e).forEach(o=>{n.setAttribute(o,String(e[o]))}),a.length&&a.forEach(o=>{const i=G(...o);n.appendChild(i)}),n};var ut=([t,e,a])=>G(t,e,a);/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pt=t=>Array.from(t.attributes).reduce((e,a)=>(e[a.name]=a.value,e),{}),ht=t=>typeof t=="string"?t:!t||!t.class?"":t.class&&typeof t.class=="string"?t.class.split(" "):t.class&&Array.isArray(t.class)?t.class:"",mt=t=>t.flatMap(ht).map(a=>a.trim()).filter(Boolean).filter((a,n,o)=>o.indexOf(a)===n).join(" "),ft=t=>t.replace(/(\w)(\w*)(_|-|\s*)/g,(e,a,n)=>a.toUpperCase()+n.toLowerCase()),X=(t,{nameAttr:e,icons:a,attrs:n})=>{var B;const o=t.getAttribute(e);if(o==null)return;const i=ft(o),d=a[i];if(!d)return console.warn(`${t.outerHTML} icon name was not found in the provided icons object.`);const s=pt(t),[p,f,U]=d,A={...f,"data-lucide":o,...n,...s},W=mt(["lucide",`lucide-${o}`,s,n]);W&&Object.assign(A,{class:W});const dt=ut([p,A,U]);return(B=t.parentNode)==null?void 0:B.replaceChild(dt,t)};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vt=["svg",c,[["path",{d:"M3.5 13h6"}],["path",{d:"m2 16 4.5-9 4.5 9"}],["path",{d:"M18 7v9"}],["path",{d:"m14 12 4 4 4-4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const bt=["svg",c,[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"}],["path",{d:"M10 12h4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gt=["svg",c,[["path",{d:"m3 16 4 4 4-4"}],["path",{d:"M7 20V4"}],["path",{d:"m21 8-4-4-4 4"}],["path",{d:"M17 4v16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yt=["svg",c,[["path",{d:"M12 5v14"}],["path",{d:"m19 12-7 7-7-7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $t=["svg",c,[["path",{d:"M7 7h10v10"}],["path",{d:"M7 17 17 7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wt=["svg",c,[["path",{d:"m5 12 7-7 7 7"}],["path",{d:"M12 19V5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xt=["svg",c,[["path",{d:"M8 2v4"}],["path",{d:"M16 2v4"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2"}],["path",{d:"M3 10h18"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kt=["svg",c,[["path",{d:"M20 6 9 17l-5-5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mt=["svg",c,[["path",{d:"m6 9 6 6 6-6"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Et=["svg",c,[["path",{d:"m9 18 6-6-6-6"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const At=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Lt=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"}],["path",{d:"M12 17h.01"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const St=["svg",c,[["path",{d:"M12 13v8"}],["path",{d:"M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"}],["path",{d:"m8 17 4-4 4 4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dt=["svg",c,[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ct=["svg",c,[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["polyline",{points:"7 10 12 15 17 10"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ht=["svg",c,[["circle",{cx:"12",cy:"12",r:"1"}],["circle",{cx:"19",cy:"12",r:"1"}],["circle",{cx:"5",cy:"12",r:"1"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tt=["svg",c,[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"}],["circle",{cx:"12",cy:"12",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zt=["svg",c,[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"M10 9H8"}],["path",{d:"M16 13H8"}],["path",{d:"M16 17H8"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qt=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M7 3v18"}],["path",{d:"M3 7.5h4"}],["path",{d:"M3 12h18"}],["path",{d:"M3 16.5h4"}],["path",{d:"M17 3v18"}],["path",{d:"M17 7.5h4"}],["path",{d:"M17 16.5h4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jt=["svg",c,[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}],["path",{d:"M2 10h20"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ut=["svg",c,[["path",{d:"M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1"}],["path",{d:"M2 13h10"}],["path",{d:"m9 16 3-3-3-3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nt=["svg",c,[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=["svg",c,[["path",{d:"M12 10v6"}],["path",{d:"M9 13h6"}],["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rt=["svg",c,[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const It=["svg",c,[["line",{x1:"22",x2:"2",y1:"12",y2:"12"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pt=["svg",c,[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ft=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}],["circle",{cx:"9",cy:"9",r:"2"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vt=["svg",c,[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wt=["svg",c,[["rect",{width:"7",height:"7",x:"3",y:"3",rx:"1"}],["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1"}],["rect",{width:"7",height:"7",x:"14",y:"14",rx:"1"}],["rect",{width:"7",height:"7",x:"3",y:"14",rx:"1"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bt=["svg",c,[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xt=["svg",c,[["path",{d:"M3 12h.01"}],["path",{d:"M3 18h.01"}],["path",{d:"M3 6h.01"}],["path",{d:"M8 12h13"}],["path",{d:"M8 18h13"}],["path",{d:"M8 6h13"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zt=["svg",c,[["line",{x1:"4",x2:"20",y1:"12",y2:"12"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=["svg",c,[["path",{d:"M9 18V5l12-2v13"}],["circle",{cx:"6",cy:"18",r:"3"}],["circle",{cx:"18",cy:"16",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yt=["svg",c,[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"}],["path",{d:"m15 5 4 4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=["svg",c,[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _t=["svg",c,[["path",{d:"m13.5 8.5-5 5"}],["path",{d:"m8.5 8.5 5 5"}],["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=["svg",c,[["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qt=["svg",c,[["path",{d:"M20 7h-9"}],["path",{d:"M14 17H5"}],["circle",{cx:"17",cy:"17",r:"3"}],["circle",{cx:"7",cy:"7",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=["svg",c,[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}],["line",{x1:"3",x2:"21",y1:"9",y2:"9"}],["line",{x1:"3",x2:"21",y1:"15",y2:"15"}],["line",{x1:"9",x2:"9",y1:"9",y2:"21"}],["line",{x1:"15",x2:"15",y1:"9",y2:"21"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=["svg",c,[["path",{d:"M3 6h18"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=["svg",c,[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["polyline",{points:"17 8 12 3 7 8"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=["svg",c,[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=({icons:t={},nameAttr:e="data-lucide",attrs:a={}}={})=>{if(!Object.values(t).length)throw new Error(`Please provide an icons object.
If you want to use all the icons you can import it like:
 \`import { createIcons, icons } from 'lucide';
lucide.createIcons({icons});\``);if(typeof document>"u")throw new Error("`createIcons()` only works in a browser environment.");const n=document.querySelectorAll(`[${e}]`);if(Array.from(n).forEach(o=>X(o,{nameAttr:e,icons:t,attrs:a})),e==="data-lucide"){const o=document.querySelectorAll("[icon-name]");o.length>0&&(console.warn("[Lucide] Some icons were found with the now deprecated icon-name attribute. These will still be replaced for backwards compatibility, but will no longer be supported in v1.0 and you should switch to data-lucide"),Array.from(o).forEach(i=>X(i,{nameAttr:"icon-name",icons:t,attrs:a})))}},j={Cloud:Dt,FolderClosed:jt,Link:Bt,Trash2:ee,HardDrive:It,ArrowUpRight:$t,Settings2:Qt,Menu:Zt,CircleHelp:Lt,FolderPlus:Ot,Upload:ae,Search:Jt,X:ne,ArrowDownUp:gt,ChevronDown:Mt,List:Xt,LayoutGrid:Wt,House:Pt,ChevronRight:Et,ArrowDown:yt,ArrowUp:wt,Ellipsis:Ht,UploadCloud:St,RotateCcw:Gt,Download:Ct,FolderInput:Ut,Info:Vt,Check:kt,CircleAlert:At,Eye:Tt,Pencil:Yt,Calendar:xt,AArrowDown:vt,Folder:Rt,Image:Ft,FileText:zt,Sheet:te,Archive:bt,Film:qt,Music:Kt,FolderOpen:Nt,SearchX:_t},l=(t,e=document)=>e.querySelector(t),v=t=>String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),r=(t,e="")=>`<i data-lucide="${t}" class="${e}" aria-hidden="true"></i>`,L=t=>t<1024?`${t} Б`:t<1048576?`${(t/1024).toLocaleString("ru",{maximumFractionDigits:1})} КБ`:`${(t/1048576).toLocaleString("ru",{maximumFractionDigits:1})} МБ`,_=t=>new Date(t).toLocaleDateString("ru",{day:"numeric",month:"short",year:"numeric"});let N,m=[],u="files",w=null,h=new Set,$=null,y="",x="name",H=!0,M="list",O=[];const T=()=>crypto.randomUUID(),S=()=>m.filter(t=>!t.deleted),b=t=>m.find(e=>e.id===t),Z=t=>{var e,a,n;return t.kind==="folder"?"folder":(e=t.mime)!=null&&e.startsWith("image/")?"image":t.mime==="application/pdf"?"file-text":/\.(xlsx|csv)$/i.test(t.name)?"sheet":/\.(zip|rar)$/i.test(t.name)?"archive":(a=t.mime)!=null&&a.startsWith("video/")?"film":(n=t.mime)!=null&&n.startsWith("audio/")?"music":"file-text"};function J(t){return`<span class="file-icon ${Z(t)}">${r(Z(t))}</span>`}function oe(t){const e=URL.createObjectURL(t);return O.push(e),e}async function se(){if(N=await new Promise((t,e)=>{const a=indexedDB.open("personal-cloud",1);a.onupgradeneeded=()=>a.result.createObjectStore("entries",{keyPath:"id"}),a.onsuccess=()=>t(a.result),a.onerror=()=>e(a.error)}),m=await new Promise((t,e)=>{const a=N.transaction("entries").objectStore("entries").getAll();a.onsuccess=()=>t(a.result),a.onerror=()=>e(a.error)}),!localStorage.getItem("cloud-initialized")&&!m.length){const t=Date.now();m=["Документы","Фотографии","Проекты"].map(a=>({id:T(),name:a,kind:"folder",parent:null,modified:t,size:0}));const e=new Blob([`Добро пожаловать в Личное облако!

Загрузите файлы кнопкой «Загрузить» или перетащите их в окно.
Создавайте папки, перемещайте файлы и восстанавливайте их из корзины.

Эта версия хранит данные в браузере на этом устройстве.
Для доступа с других устройств и публичных ссылок нужен сервер.`],{type:"text/plain"});m.push({id:T(),name:"Начните здесь.txt",kind:"file",parent:null,modified:t,size:e.size,mime:e.type,blob:e}),await Q(),localStorage.setItem("cloud-initialized","1")}g()}async function Q(){await new Promise((t,e)=>{const a=N.transaction("entries","readwrite"),n=a.objectStore("entries");n.clear(),m.forEach(o=>n.put(o)),a.oncomplete=t,a.onerror=()=>e(a.error),a.onabort=()=>e(a.error)})}async function k(t,e){const a=structuredClone(m);try{t(),g(),await Q(),e&&E(e)}catch{m=a,g(),E("Не удалось сохранить. Возможно, хранилище браузера заполнено.",!0)}}function tt(){let t=m.filter(e=>{var a;return u==="trash"?e.deleted&&!((a=b(e.parent))!=null&&a.deleted):u==="links"?!e.deleted&&e.shared:!e.deleted&&(y?!0:e.parent===w)});return y&&(t=t.filter(e=>e.name.toLocaleLowerCase().includes(y.toLocaleLowerCase()))),t.sort((e,a)=>(e.kind===a.kind?0:e.kind==="folder"?-1:1)||(x==="name"?e.name.localeCompare(a.name,"ru"):(e[x]||0)-(a[x]||0))*(H?1:-1))}function P(t){const e=[];let a=b(t);const n=new Set;for(;a&&!n.has(a.id);)e.unshift(a),n.add(a.id),a=b(a.parent);return e}function D(t,e){return P(t).some(a=>a.id===e)}function K(t){u=t,w=null,h.clear(),$=null,y="",g()}function et(t){w=t,u="files",y="",h.clear(),$=null,g()}function g(){var i,d;O.forEach(URL.revokeObjectURL),O=[];const t=tt(),e=b($),a=m.reduce((s,p)=>s+(p.size||0),0),n=S().filter(s=>s.kind==="file").length,o={files:"Мои файлы",links:"Общие ссылки",trash:"Корзина"};l("#app").innerHTML=`<div class="layout">
    <aside class="sidebar" id="sidebar"><a class="brand" href="#" aria-label="Личное облако, главная">${r("cloud")}<span>Личное<span class="brand-sub">облако</span></span><span class="brand-dot"></span></a>
    <div class="workspace-label">ЛИЧНОЕ ПРОСТРАНСТВО</div><nav aria-label="Основная навигация">${[["files","folder-closed","Мои файлы"],["links","link","Общие ссылки"],["trash","trash-2","Корзина"]].map(([s,p,f])=>`<button class="nav-item ${u===s?"active":""}" data-nav="${s}">${r(p)}<span>${f}</span>${s==="files"?`<span class="nav-count">${n}</span>`:""}</button>`).join("")}</nav>
    <div class="sidebar-bottom"><div class="storage-heading">${r("hard-drive")}<span>Хранилище браузера</span></div><div class="storage-value">${L(a)} <span>занято файлами</span></div><div class="storage-track"><span id="storage-fill"></span></div><p>Доступно на этом устройстве</p><button class="storage-details" data-action="storage">Подробнее ${r("arrow-up-right")}</button></div>
    <button class="profile" data-action="settings"><span class="avatar">Л</span><span>Личное пространство<small>Локальная версия</small></span>${r("settings-2")}</button></aside>
    <div class="sidebar-shade" data-action="close-nav"></div>
    <main><header class="topbar"><button class="icon-button mobile-menu" data-action="menu" aria-label="Открыть навигацию">${r("menu")}</button><div class="top-location">Пространство <span>/</span> <strong>${o[u]}</strong></div><div class="top-right"><span class="local-tag"><span></span>На этом устройстве</span><button class="icon-button" data-action="help" aria-label="Помощь">${r("circle-help")}</button><span class="avatar small">Л</span></div></header>
    <div class="content"><div class="page-heading"><div><div class="eyebrow">ВАШЕ ЛИЧНОЕ ОБЛАКО</div><h1>${v(u==="files"&&w?(i=b(w))==null?void 0:i.name:o[u])}</h1><p>${u==="files"?"Всё нужное — на своём месте.":u==="links"?"Файлы, которые вы подготовили для обмена.":"Удалённые файлы можно восстановить."}</p></div><div class="heading-actions">${u==="files"?`<button class="button secondary" data-action="new-folder">${r("folder-plus")}<span>Новая папка</span></button><button class="button primary" data-action="upload">${r("upload")}<span>Загрузить файлы</span></button>`:u==="trash"?`<button class="button secondary danger" data-action="empty-trash" ${t.length?"":"disabled"}>${r("trash-2")}Очистить корзину</button>`:""}</div></div>
    ${u==="links"?`<div class="notice">${r("info")}<span>Публичные ссылки появятся после подключения сервера. Здесь можно подготовить список файлов для обмена.</span></div>`:""}
    <div class="file-toolbar"><label class="search">${r("search")}<input id="search" placeholder="Поиск файлов и папок" aria-label="Поиск файлов и папок" value="${v(y)}" autocomplete="off">${y?`<button class="icon-button" data-action="clear-search" aria-label="Очистить поиск">${r("x")}</button>`:"<kbd>/</kbd>"}</label><div class="toolbar-right"><button class="sort-button" data-action="sort">${r("arrow-down-up")}<span>${x==="name"?"По названию":x==="size"?"По размеру":"По дате"}</span>${r("chevron-down")}</button><div class="view-toggle"><button class="icon-button ${M==="list"?"on":""}" data-view="list" aria-label="Список" aria-pressed="${M==="list"}">${r("list")}</button><button class="icon-button ${M==="grid"?"on":""}" data-view="grid" aria-label="Плитки" aria-pressed="${M==="grid"}">${r("layout-grid")}</button></div></div></div>
    <div class="breadcrumb"><button data-folder="">${r("house")}<span>${u==="files"?"Все файлы":o[u]}</span></button>${u==="files"?P(w).map(s=>`${r("chevron-right")}<button data-folder="${s.id}">${v(s.name)}</button>`).join(""):""}<span class="item-count">${t.length} ${ie(t.length,"элемент","элемента","элементов")}${y?" найдено":""}</span></div>
    <div class="files-area ${e?"with-preview":""}"><section class="file-panel" aria-label="Файлы"><div class="table-head"><label class="check"><input type="checkbox" id="select-all" aria-label="Выбрать все файлы" ${t.length&&t.every(s=>h.has(s.id))?"checked":""}></label><button data-sort="name">Название ${r(x==="name"&&!H?"arrow-down":"arrow-up")}</button><button class="size-col" data-sort="size">Размер</button><button class="date-col" data-sort="modified">Изменено</button><span></span></div><div class="file-items ${M}">${t.map(s=>`<div class="file-row ${h.has(s.id)?"selected":""} ${$===s.id?"previewed":""}" data-id="${s.id}" tabindex="0" role="group" aria-label="${v(s.name)}"><label class="check"><input type="checkbox" data-select="${s.id}" aria-label="Выбрать ${v(s.name)}" ${h.has(s.id)?"checked":""}></label><button class="file-name" data-open="${s.id}">${J(s)}<span class="file-label">${v(s.name)}<small>${s.kind==="folder"?"Папка":L(s.size)}</small></span>${s.shared?r("link","shared-mark"):""}</button><span class="size-col">${s.kind==="folder"?"—":L(s.size)}</span><span class="date-col">${_(s.modified)}</span><button class="icon-button row-more" data-more="${s.id}" aria-label="Действия: ${v(s.name)}">${r("ellipsis")}</button></div>`).join("")||`<div class="empty">${r(y?"search-x":u==="trash"?"trash-2":u==="links"?"link":"folder-open")}<h2>${y?"Ничего не найдено":u==="trash"?"Корзина пуста":u==="links"?"Пока нет файлов для обмена":"Здесь пока пусто"}</h2><p>${y?"Попробуйте другое название.":u==="trash"?"Удалённые файлы появятся здесь.":u==="links"?"Выберите файл и нажмите «Поделиться».":"Загрузите файлы или создайте первую папку."}</p>${u==="files"&&!y?'<button class="button secondary" data-action="upload">Загрузить файлы</button>':""}</div>`}</div><div class="drop-hint">${r("upload-cloud")}<span>Перетащите файлы сюда для загрузки</span></div></section>${e?le(e):""}</div>
    <footer class="content-footer"><span>${r("hard-drive")} Файлы хранятся в этом браузере</span><button data-action="help">Как это работает ${r("arrow-up-right")}</button></footer></div>
    ${h.size?`<div class="selection-bar"><button class="icon-button" data-action="deselect" aria-label="Снять выделение">${r("x")}</button><span class="selection-count">Выбрано: <strong>${h.size}</strong></span><div class="selection-actions">${u==="trash"?`<button data-action="restore">${r("rotate-ccw")}<span>Восстановить</span></button><button class="danger" data-action="delete">${r("trash-2")}<span>Удалить навсегда</span></button>`:`<button data-action="download">${r("download")}<span>Скачать</span></button><button data-action="share">${r("link")}<span>Поделиться</span></button><button data-action="move">${r("folder-input")}<span>Переместить</span></button><button data-action="trash">${r("trash-2")}<span>В корзину</span></button>`}</div></div>`:""}
    </main></div><input id="file-input" type="file" multiple hidden><div id="overlay-root"></div><div id="toast-root" role="status" aria-live="polite"></div><div id="drop-overlay">${r("upload-cloud")}<h2>Отпустите файлы для загрузки</h2><p>В текущую папку</p></div>`,re(),q({icons:j}),(d=navigator.storage)==null||d.estimate().then(({quota:s})=>{const p=l("#storage-fill");p&&(p.style.width=`${s?Math.min(100,a/s*100):0}%`)}).catch(()=>{})}function ie(t,e,a,n){return t%10===1&&t%100!==11?e:t%10>=2&&t%10<=4&&(t%100<12||t%100>14)?a:n}function le(t){var a,n,o,i,d;let e="";if(t.blob){const s=oe(t.blob);e=(a=t.mime)!=null&&a.startsWith("image/")?`<img src="${s}" alt="${v(t.name)}">`:(n=t.mime)!=null&&n.startsWith("video/")?`<video controls src="${s}"></video>`:(o=t.mime)!=null&&o.startsWith("audio/")?`<audio controls src="${s}"></audio>`:t.mime==="application/pdf"?`<iframe src="${s}" title="${v(t.name)}"></iframe>`:(i=t.mime)!=null&&i.startsWith("text/")||/\.(md|json|csv|log)$/i.test(t.name)?'<pre id="text-preview">Загрузка…</pre>':`<div class="unsupported">${J(t)}<p>Предпросмотр недоступен.<br>Скачайте файл, чтобы открыть его.</p></div>`}return`<aside class="preview-panel" aria-label="Предпросмотр"><div class="preview-heading"><span>ПРЕДПРОСМОТР</span><button class="icon-button" data-action="close-preview" aria-label="Закрыть предпросмотр">${r("x")}</button></div><div class="preview-media">${e}</div><h2>${v(t.name)}</h2><span class="file-type">${v(t.mime||"Файл")}</span><dl><div><dt>Размер</dt><dd>${L(t.size)}</dd></div><div><dt>Изменено</dt><dd>${_(t.modified)}</dd></div><div><dt>Расположение</dt><dd>${v(((d=b(t.parent))==null?void 0:d.name)||"Все файлы")}</dd></div></dl><button class="button primary full" data-download="${t.id}">${r("download")}Скачать файл</button>${t.deleted?"":`<button class="button secondary full" data-share="${t.id}">${r("link")}Поделиться</button>`}</aside>`}function re(){document.querySelectorAll("[data-nav]").forEach(e=>e.onclick=()=>K(e.dataset.nav)),l(".brand").onclick=e=>{e.preventDefault(),K("files")},document.querySelectorAll("[data-action]").forEach(e=>e.onclick=a=>ce(e.dataset.action,a)),document.querySelectorAll("[data-folder]").forEach(e=>e.onclick=()=>et(e.dataset.folder||null)),document.querySelectorAll("[data-view]").forEach(e=>e.onclick=()=>{M=e.dataset.view,g()}),document.querySelectorAll("[data-sort]").forEach(e=>e.onclick=()=>at(e.dataset.sort)),document.querySelectorAll("[data-open]").forEach(e=>e.onclick=()=>R(e.dataset.open)),document.querySelectorAll("[data-select]").forEach(e=>e.onchange=()=>{e.checked?h.add(e.dataset.select):h.delete(e.dataset.select),g()}),document.querySelectorAll("[data-more]").forEach(e=>e.onclick=a=>Y(a,e.dataset.more)),document.querySelectorAll("[data-download]").forEach(e=>e.onclick=()=>F([e.dataset.download])),document.querySelectorAll("[data-share]").forEach(e=>e.onclick=()=>V([e.dataset.share])),document.querySelectorAll(".file-row").forEach(e=>{e.oncontextmenu=a=>{a.preventDefault(),Y(a,e.dataset.id)},e.onkeydown=a=>{a.target===e&&a.key==="Enter"&&R(e.dataset.id)}}),l("#select-all").onchange=e=>{tt().forEach(a=>e.target.checked?h.add(a.id):h.delete(a.id)),g()},l("#search").oninput=e=>{const a=e.target.selectionStart;y=e.target.value,h.clear(),g(),l("#search").focus(),l("#search").setSelectionRange(a,a)},l("#file-input").onchange=e=>st([...e.target.files]);const t=b($);l("#text-preview")&&(t!=null&&t.blob)&&t.blob.slice(0,2e5).text().then(e=>{$===t.id&&l("#text-preview")&&(l("#text-preview").textContent=e+(t.size>2e5?`
… Показаны первые 200 КБ`:""))})}function R(t){const e=b(t);if(e.kind==="folder"){if(e.deleted)return E("Сначала восстановите папку");et(t)}else $=t,g()}function at(t){H=x===t?!H:!0,x=t,g()}function ce(t,e){const a=[...h];t==="upload"&&l("#file-input").click(),t==="new-folder"&&nt(),t==="deselect"&&(h.clear(),g()),t==="close-preview"&&($=null,g()),t==="download"&&F(a),t==="share"&&V(a),t==="move"&&rt(a),t==="trash"&&it(a),t==="restore"&&lt(a),t==="delete"&&I(a),t==="empty-trash"&&I(m.filter(n=>n.deleted).map(n=>n.id)),t==="clear-search"&&(y="",g(),l("#search").focus()),t==="menu"&&l(".layout").classList.add("nav-open"),t==="close-nav"&&l(".layout").classList.remove("nav-open"),t==="sort"&&ct(e,[["name","По названию","a-arrow-down"],["modified","По дате изменения","calendar"],["size","По размеру","hard-drive"]].map(([n,o,i])=>({label:o,icon:i,run:()=>at(n)}))),["help","settings","storage"].includes(t)&&ue(t)}function E(t,e=!1){const a=l("#toast-root");a.innerHTML=`<div class="toast ${e?"error":""}">${r(e?"circle-alert":"check")}${v(t)}</div>`,q({icons:j}),setTimeout(()=>a.replaceChildren(),4500)}function C(t,e,a,n){const o=document.activeElement;l("#overlay-root").innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-heading"><h2 id="modal-title">${t}</h2><button class="icon-button" data-close aria-label="Закрыть">${r("x")}</button></div><div class="modal-body">${e}</div><div class="modal-actions">${a}</div></section></div>`;const i=()=>{l("#overlay-root").replaceChildren(),o==null||o.focus()};document.querySelectorAll("[data-close]").forEach(d=>d.onclick=i),l(".modal-backdrop").onclick=d=>{d.target===d.currentTarget&&i()},l(".modal").onkeydown=d=>{if(d.key==="Escape"&&i(),d.key==="Tab"){const s=[...l(".modal").querySelectorAll("button:not(:disabled),input,select,a[href]")],p=s[0],f=s.at(-1);d.shiftKey&&document.activeElement===p?(d.preventDefault(),f.focus()):!d.shiftKey&&document.activeElement===f&&(d.preventDefault(),p.focus())}},n==null||n(i),q({icons:j}),setTimeout(()=>{var d;return(d=l(".modal input")||l(".modal button"))==null?void 0:d.focus()},0)}function nt(t){const e=b(t);C(e?"Переименовать":"Новая папка",`<label class="field-label" for="entry-name">Название</label><input class="text-input" id="entry-name" maxlength="200" value="${v((e==null?void 0:e.name)||"")}" placeholder="Например, Документы"><p class="form-error" id="name-error"></p>`,`<button class="button secondary" data-close>Отмена</button><button class="button primary" id="save-name">${e?"Сохранить":"Создать папку"}</button>`,a=>{const n=async()=>{const o=l("#entry-name").value.trim();if(!o||/[\/\\\x00-\x1f]/.test(o)||o==="."||o==="..")return l("#name-error").textContent="Введите название без слешей и служебных символов.";if(S().some(i=>i.id!==t&&i.parent===(e?e.parent:w)&&i.name===o))return l("#name-error").textContent="Такое название уже есть в этой папке.";a(),await k(()=>{e?(e.name=o,e.modified=Date.now()):m.push({id:T(),name:o,kind:"folder",parent:w,modified:Date.now(),size:0})},e?"Название изменено":"Папка создана")};l("#save-name").onclick=n,l("#entry-name").onkeydown=o=>{o.key==="Enter"&&n()},l("#entry-name").select()})}function ot(t,e){let a=t,n=1;const o=t.lastIndexOf("."),i=o>0?t.slice(0,o):t,d=o>0?t.slice(o):"";for(;S().some(s=>s.parent===e&&s.name===a);)a=`${i} (${n++})${d}`;return a}async function st(t){if(u!=="files")return E("Откройте «Мои файлы» для загрузки");t.length&&await k(()=>t.forEach(e=>m.push({id:T(),name:ot(e.name,w),kind:"file",parent:w,modified:Date.now(),size:e.size,mime:e.type,blob:e})),`Загружено файлов: ${t.length}`)}function F(t){const e=t.map(b).filter(a=>a==null?void 0:a.blob);if(!e.length)return E("Откройте папку и выберите файлы для скачивания");for(const a of e){const n=URL.createObjectURL(a.blob),o=document.createElement("a");o.href=n,o.download=a.name,o.click(),setTimeout(()=>URL.revokeObjectURL(n),1e4)}e.length<t.length&&E("Скачаны файлы. Папки нужно открыть отдельно.")}function it(t){k(()=>{m.forEach(e=>{t.some(a=>D(e.id,a))&&(e.deleted=Date.now())}),h.clear(),$=null},"Перемещено в корзину")}function lt(t){k(()=>{m.filter(a=>t.some(n=>D(a.id,n))).forEach(a=>delete a.deleted),t.forEach(a=>{var o;const n=b(a);n&&(!b(n.parent)||(o=b(n.parent))!=null&&o.deleted)&&(n.parent=null),n&&(n.name=de(n))}),h.clear()},"Восстановлено")}function de(t){const e=t.name;t.name="";const a=ot(e,t.parent);return t.name=e,a}function I(t){C("Удалить навсегда?",`<p>Будет удалено элементов: <strong>${t.length}</strong>. Содержимое выбранных папок тоже будет удалено. Восстановить их не получится.</p>`,'<button class="button secondary" data-close>Отмена</button><button class="button destructive" id="confirm-delete">Удалить навсегда</button>',e=>{l("#confirm-delete").onclick=()=>{e(),k(()=>{const a=m.filter(n=>t.some(o=>D(n.id,o))).map(n=>n.id);m=m.filter(n=>!a.includes(n.id)),h.clear(),$=null},"Удалено навсегда")}})}function rt(t){const e=S().filter(a=>a.kind==="folder"&&!t.some(n=>D(a.id,n)));C("Переместить",`<p>Выберите папку назначения.</p><label class="field-label" for="destination">Папка</label><select class="text-input" id="destination"><option value="">Все файлы</option>${e.map(a=>`<option value="${a.id}">${v(P(a.id).map(n=>n.name).join(" / "))}</option>`).join("")}</select><p class="form-error" id="move-error"></p>`,'<button class="button secondary" data-close>Отмена</button><button class="button primary" id="confirm-move">Переместить</button>',a=>{l("#confirm-move").onclick=()=>{const n=l("#destination").value||null,o=t.map(b).filter(i=>i&&!t.some(d=>d!==i.id&&D(i.id,d)));if(o.some(i=>S().some(d=>d.parent===n&&d.name===i.name&&d.id!==i.id)))return l("#move-error").textContent="В папке назначения уже есть элемент с таким названием.";a(),k(()=>{o.forEach(i=>{i.parent=n,i.modified=Date.now()}),h.clear()},"Перемещено")}})}function V(t){const e=t.map(b).filter(Boolean),a=e.every(n=>n.shared);C("Поделиться",`<div class="dialog-symbol">${r("link")}</div><p><strong>${e.length===1?v(e[0].name):`Выбрано элементов: ${e.length}`}</strong></p><p>Сейчас файлы находятся только в этом браузере. Публичную ссылку можно будет создать после подключения серверного хранилища.</p><p>Пока можно ${a?"убрать их из":"добавить их в"} раздел «Общие ссылки» или скачать файл и отправить его самостоятельно.</p>`,`<button class="button secondary" data-close>Закрыть</button><button class="button primary" id="prepare-share">${a?"Убрать из списка":"Подготовить к обмену"}</button>`,n=>{l("#prepare-share").onclick=()=>{n(),k(()=>e.forEach(o=>o.shared=!a),a?"Убрано из общих ссылок":"Добавлено в общие ссылки")}})}function ue(t){const e=m.reduce((a,n)=>a+(n.size||0),0);C(t==="storage"?"Хранилище":t==="settings"?"Личное пространство":"Как это работает",`<div class="dialog-symbol">${r(t==="storage"?"hard-drive":"cloud")}</div><p>Это локальная версия личного облака. Файлы сохраняются в браузере на этом устройстве и остаются после обновления страницы.</p><dl class="info-list"><div><dt>Занято файлами</dt><dd>${L(e)}</dd></div><div><dt>Файлов</dt><dd>${m.filter(a=>a.kind==="file").length}</dd></div><div><dt>Хранение</dt><dd>В этом браузере</dd></div></dl><p>Очистка данных сайта удалит сохранённые файлы. Корзина тоже занимает место. Для синхронизации устройств и публичных ссылок нужно подключить backend на VPS.</p>${t==="help"?"<p><kbd>/</kbd> — поиск · <kbd>Esc</kbd> — закрыть окно или снять выделение. Файлы можно загружать перетаскиванием.</p>":""}`,'<button class="button primary" data-close>Понятно</button>')}function Y(t,e){const a=b(e),n=h.has(e)?[...h]:[e];ct(t,a.deleted?[{label:"Восстановить",icon:"rotate-ccw",run:()=>lt(n)},{label:"Удалить навсегда",icon:"trash-2",danger:!0,run:()=>I(n)}]:[{label:a.kind==="folder"?"Открыть папку":"Предпросмотр",icon:a.kind==="folder"?"folder-open":"eye",run:()=>R(e)},...a.kind==="file"?[{label:"Скачать",icon:"download",run:()=>F(n)}]:[],{label:"Поделиться",icon:"link",run:()=>V(n)},{label:"Переименовать",icon:"pencil",run:()=>nt(e)},{label:"Переместить",icon:"folder-input",run:()=>rt(n)},{label:"В корзину",icon:"trash-2",danger:!0,run:()=>it(n)}])}function ct(t,e){var d,s;(d=l(".context-menu"))==null||d.remove();const a=document.createElement("div");a.className="context-menu",a.setAttribute("role","menu"),a.innerHTML=e.map((p,f)=>`<button role="menuitem" class="${p.danger?"danger":""}" data-menu-index="${f}">${r(p.icon)}${p.label}</button>`).join(""),document.body.append(a);const n=(s=t.currentTarget)==null?void 0:s.getBoundingClientRect(),o=t.type==="contextmenu"?t.clientX:(n==null?void 0:n.right)||t.clientX,i=t.type==="contextmenu"?t.clientY:(n==null?void 0:n.bottom)||t.clientY;a.style.left=`${Math.max(8,Math.min(o-200,innerWidth-220))}px`,a.style.top=`${Math.max(8,Math.min(i+5,innerHeight-a.offsetHeight-10))}px`,a.querySelectorAll("button").forEach((p,f)=>p.onclick=()=>{a.remove(),e[f].run()}),a.onkeydown=p=>{var A;const f=[...a.querySelectorAll("button")];let U=f.indexOf(document.activeElement);(p.key==="ArrowDown"||p.key==="ArrowUp")&&(p.preventDefault(),f[(U+(p.key==="ArrowDown"?1:f.length-1))%f.length].focus()),p.key==="Escape"&&(a.remove(),(A=t.currentTarget)==null||A.focus())},q({icons:j}),a.querySelector("button").focus(),setTimeout(()=>document.addEventListener("click",function p(f){a.contains(f.target)||(a.remove(),document.removeEventListener("click",p))},{capture:!0}),0)}let z=0;document.addEventListener("dragenter",t=>{var e,a;(e=t.dataTransfer)!=null&&e.types.includes("Files")&&(t.preventDefault(),z++,u==="files"&&((a=l("#drop-overlay"))==null||a.classList.add("show")))});document.addEventListener("dragover",t=>{var e;(e=t.dataTransfer)!=null&&e.types.includes("Files")&&t.preventDefault()});document.addEventListener("dragleave",()=>{var t;--z<=0&&(z=0,(t=l("#drop-overlay"))==null||t.classList.remove("show"))});document.addEventListener("drop",t=>{var e;t.preventDefault(),z=0,(e=l("#drop-overlay"))==null||e.classList.remove("show"),st([...t.dataTransfer.files])});document.addEventListener("keydown",t=>{var e,a,n;if(t.key==="Escape"){if(l(".modal"))return;(e=l(".context-menu"))==null||e.remove(),(a=l(".layout"))==null||a.classList.remove("nav-open"),h.clear(),$=null,g()}t.key==="/"&&!["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName)&&!l(".modal")&&(t.preventDefault(),(n=l("#search"))==null||n.focus())});se().catch(()=>{l("#app").innerHTML='<div class="fatal"><h1>Хранилище браузера недоступно</h1><p>Разрешите хранение данных сайта и обновите страницу.</p><button onclick="location.reload()">Попробовать снова</button></div>'});
